
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class DemoApplication {

    
    public static void main(String[] args) throws SQLException {
        String query = "SELECT companyname "+ "FROM customers " + "WHERE country ='Mexico'"; 
        Connection connection = createConnection();
        Statement stmt = (Statement) connection.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        while(rs.next()){
            String str = rs.getString("companyname");
            System.out.println(str);
        }
        AddReservationFrame res = new AddReservationFrame();
        res.show();
    }
  
    public static Connection createConnection(){

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/northwind", "root", "12345678");
                System.out.println("Connection sucess!");
                return con;
            } catch (ClassNotFoundException | SQLException e) {
            }
        return null;
        }

}
